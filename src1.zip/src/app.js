import cors from "cors";
import express from "express";
import authRoutes from "./modules/auth/auth.routes.js";
import memberRoutes from "./modules/members/member.routes.js";
import requestRoutes from "./modules/requests/request.routes.js";
import sensorRoutes from "./modules/sensors/sensor.routes.js";
import vehicleRoutes from "./modules/status/vehicle.routes.js";

const app = express();

app.use(cors());
app.use(express.json());

app.use("/api/auth", authRoutes);

app.get("/health", (req, res) => {
  res.json({ status: "OK", message: "Backend running" });
});

app.use("/api/vehicle", vehicleRoutes);

app.use("/api/sensors", sensorRoutes);

app.use("/api/requests", requestRoutes);
app.use("/api/members", memberRoutes);

export default app;
