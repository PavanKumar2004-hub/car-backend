import { Member } from "../modules/members/member.model.js";

/**
 * Resolves context role for current dashboard
 *
 * OWNER  → no member record
 * FAMILY → member.role === FAMILY
 * FRIEND → member.role === FRIEND
 */
export const resolveContextRole = async (req, res, next) => {
  try {
    // Dashboard owner is the logged-in user by default
    // (single-dashboard assumption)
    const ownerId = req.user._id;

    // Check if user is a member under another owner
    const member = await Member.findOne({
      userId: req.user._id,
    });

    if (!member) {
      req.contextRole = "OWNER";
    } else {
      req.contextRole = member.role; // FAMILY | FRIEND
      req.dashboardOwnerId = member.ownerId;
    }

    next();
  } catch (err) {
    return res.status(500).json({
      message: "Failed to resolve context role",
    });
  }
};
