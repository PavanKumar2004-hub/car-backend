import mqtt from "mqtt";
import { processSensorPayload } from "../../modules/sensors/sensor.controller.js";

/* ================= EMQX CLOUD CONFIG ================= */

const MQTT_BROKER_URL = "mqtts://j0014f06.ala.asia-southeast1.emqxsl.com:8883";

const MQTT_TOPIC = "vehicle/+/telemetry";

/* ================= CONNECT OPTIONS ================= */

export const mqttClient = mqtt.connect(MQTT_BROKER_URL, {
  username: "pavan",
  password: "pavankumar2004",

  reconnectPeriod: 3000,
  clean: true,

  // TLS fix for some environments
  rejectUnauthorized: false,
});

/* ================= CONNECTION EVENTS ================= */

mqttClient.on("connect", () => {
  console.log("✅ EMQX MQTT connected");

  mqttClient.subscribe(MQTT_TOPIC, (err) => {
    if (err) {
      console.error("❌ Subscribe error:", err);
    } else {
      console.log("📡 Subscribed to:", MQTT_TOPIC);
    }
  });
});

/* ================= MESSAGE HANDLER ================= */

mqttClient.on("message", async (topic, message) => {
  try {
    const payload = JSON.parse(message.toString());

    console.log("📥 MQTT Message:", topic);

    await processSensorPayload(payload);
  } catch (err) {
    console.error("❌ MQTT payload error:", err.message);
  }
});

/* ================= DEBUG EVENTS ================= */

mqttClient.on("error", (err) => {
  console.error("❌ MQTT connection error:", err.message);
});

mqttClient.on("close", () => {
  console.warn("⚠️ MQTT connection closed");
});

mqttClient.on("reconnect", () => {
  console.log("🔄 MQTT reconnecting...");
});
