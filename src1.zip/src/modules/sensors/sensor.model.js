import mongoose from "mongoose";

const sensorSchema = new mongoose.Schema(
  {
    alcohol: Number,

    ultrasonic: {
      front: Number,
      back: Number,
    },

    surface: {
      left: Number,
      right: Number,
    },

    accel: {
      x: Number,
      y: Number,
      z: Number,
    },

    speed: Number,

    location: {
      lat: Number,
      lng: Number,
    },

    status: {
      alcohol: String,
      obstacle: String,
      surface: String,
      accident: String,
      vehicle: String,
    },
  },
  { timestamps: true }
);

export const Sensor = mongoose.model("Sensor", sensorSchema);
