import mongoose from "mongoose";

const requestSchema = new mongoose.Schema(
  {
    alcoholLevel: {
      type: Number,
      required: true,
    },

    status: {
      type: String,
      enum: ["PENDING", "APPROVED", "REJECTED"],
      default: "PENDING",
    },
  },
  { timestamps: true }
);

export const Request = mongoose.model("Request", requestSchema);
