import express from "express";
import { protect } from "../../middlewares/auth.middleware.js";
import { askToStartCar, getRequestDetails } from "./request.controller.js";
import { submitDecision } from "./decision.controller.js";

const router = express.Router();

router.use(protect);

router.post("/ask", askToStartCar);
router.get("/:id", getRequestDetails);
router.post("/decision", submitDecision);

export default router;
