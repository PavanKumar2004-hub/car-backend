import { getIO } from "../../sockets/socket.js";
import { updateVehicleStateInternal } from "../status/vehicle.internal.js";
import { Approval } from "./approval.model.js";
import { Request } from "./request.model.js";

export const submitDecision = async (req, res) => {
  const { requestId, memberId, decision } = req.body;

  const approval = await Approval.findOneAndUpdate(
    { requestId, memberId },
    { decision },
    { new: true }
  );

  if (!approval) {
    return res.status(404).json({ message: "Approval record not found" });
  }

  // Recalculate request status
  const approvals = await Approval.find({ requestId });

  let status = "PENDING";

  if (approvals.some((a) => a.decision === "APPROVED")) {
    status = "APPROVED";
  } else if (approvals.every((a) => a.decision === "REJECTED")) {
    status = "REJECTED";
  }

  await Request.findByIdAndUpdate(requestId, { status });

  // Notify dashboard
  const io = getIO();
  io.emit("request:update", { requestId, status });

  await updateVehicleStateInternal();

  res.json({ status });
};
