import mongoose from "mongoose";

const vehicleSchema = new mongoose.Schema(
  {
    speedAllowed: {
      type: Number,
      default: 0, // km/h
    },

    lockState: {
      type: String,
      enum: ["LOCKED", "LIMITED", "UNLOCKED"],
      default: "LOCKED",
    },

    reason: {
      type: String,
    },
  },
  { timestamps: true }
);

export const Vehicle = mongoose.model("Vehicle", vehicleSchema);
