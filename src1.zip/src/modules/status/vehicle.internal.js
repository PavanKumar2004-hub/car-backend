import { getIO } from "../../sockets/socket.js";
import { Request } from "../requests/request.model.js";
import { Sensor } from "../sensors/sensor.model.js";
import { evaluateVehicleControl } from "./control.engine.js";
import { Vehicle } from "./vehicle.model.js";

export const updateVehicleStateInternal = async () => {
  const sensor = await Sensor.findOne();
  if (!sensor) return;

  const request = await Request.findOne().sort({ createdAt: -1 });
  const approvalStatus = request ? request.status : "PENDING";

  const decision = evaluateVehicleControl({
    sensorStatus: sensor.status,
    approvalStatus,
  });

  await Vehicle.findOneAndUpdate({}, decision, {
    upsert: true,
    new: true,
  });

  const io = getIO();
  io.emit("vehicle:update", decision);
};
