export const SPEED_POLICY = {
  NORMAL: 60, // km/h
  LIMITED: 20, // km/h (member approved)
  STOPPED: 0,
};
