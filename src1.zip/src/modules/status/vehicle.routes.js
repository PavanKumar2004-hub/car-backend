import express from "express";
import { protect } from "../../middlewares/auth.middleware.js";
import { updateVehicleState } from "./vehicle.controller.js";

const router = express.Router();

router.use(protect);

router.post("/evaluate", updateVehicleState);

export default router;
