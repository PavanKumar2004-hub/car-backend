import express from "express";
import { updateSensors } from "./sensor.controller.js";

const router = express.Router();

router.post("/update", updateSensors);

export default router;
