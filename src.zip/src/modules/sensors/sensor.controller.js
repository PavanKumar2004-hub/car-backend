import { getIO } from "../../sockets/socket.js";
import { updateVehicleStateInternal } from "../status/vehicle.internal.js";
import { evaluateRules } from "./rules.engine.js";
import { Sensor } from "./sensor.model.js";

export const updateSensors = async (req, res) => {
  const data = req.body;

  const status = evaluateRules(data);

  const snapshot = {
    ...data,
    status,
  };

  // Maintain single document
  await Sensor.findOneAndUpdate({}, snapshot, { upsert: true, new: true });

  const io = getIO();
  io.emit("sensor:update", snapshot);
  await updateVehicleStateInternal();

  res.json({
    message: "Sensor data updated",
    status,
  });
};
