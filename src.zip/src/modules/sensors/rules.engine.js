export const evaluateRules = (data) => {
  // 🔐 SAFE NORMALIZATION (IMPORTANT)
  const alcohol = data.alcohol ?? 0;

  const ultrasonic = data.ultrasonic ?? {};
  const front = ultrasonic.front ?? Infinity;
  const back = ultrasonic.back ?? Infinity;

  const surface = data.surface ?? {};
  const left = surface.left ?? Infinity;
  const right = surface.right ?? Infinity;

  const accel = data.accel ?? { x: 0, y: 0, z: 0 };
  const ax = accel.x ?? 0;
  const ay = accel.y ?? 0;
  const az = accel.z ?? 0;

  const status = {
    alcohol: "SAFE",
    obstacle: "SAFE",
    surface: "SAFE",
    accident: "SAFE",
    vehicle: "STOPPED",
  };

  /* Alcohol */
  if (alcohol > 0.3) {
    status.alcohol = "DANGER";
  }

  /* Obstacle */
  if (front < 30 || back < 30) {
    status.obstacle = "WARNING";
  }

  if (front < 15 || back < 15) {
    status.obstacle = "DANGER";
  }

  /* Surface / Footpath */
  if (left < 20 || right < 20) {
    status.surface = "WARNING";
  }

  /* Accident Detection */
  const accelMagnitude = Math.sqrt(ax ** 2 + ay ** 2 + az ** 2);

  if (accelMagnitude > 25) {
    status.accident = "ACCIDENT";
  }

  /* Vehicle State */
  if (status.alcohol === "SAFE" && status.accident === "SAFE") {
    status.vehicle = "RUNNING";
  }

  return status;
};
