import { getIO } from "../../sockets/socket.js";
import { Member } from "../members/member.model.js";
import { Approval } from "./approval.model.js";
import { Request } from "./request.model.js";

export const askToStartCar = async (req, res) => {
  const { alcoholLevel } = req.body;

  // Optional guard (recommended)
  if (alcoholLevel <= 0.3) {
    return res.status(400).json({
      message: "Alcohol level safe. Request not required.",
    });
  }

  // ✅ Only ACTIVE family members
  const members = await Member.find({
    status: "ACTIVE",
    relation: { $in: ["Father", "Mother", "Brother", "Sister"] },
  });

  if (members.length === 0) {
    return res.status(400).json({
      message: "No family members available",
    });
  }

  // Create request
  const request = await Request.create({
    alcoholLevel,
  });

  // Create approval entries
  const approvals = members.map((m) => ({
    requestId: request._id,
    memberId: m._id,
  }));

  await Approval.insertMany(approvals);

  // Notify dashboard
  const io = getIO();
  io.emit("request:new", {
    requestId: request._id,
  });

  res.status(201).json({
    message: "Request sent to family members",
    requestId: request._id,
  });
};

export const getRequestDetails = async (req, res) => {
  const { id } = req.params;

  const approvals = await Approval.find({ requestId: id }).populate(
    "memberId",
    "name relation"
  );

  res.json(approvals);
};
