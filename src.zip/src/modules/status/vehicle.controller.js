import { Sensor } from "../sensors/sensor.model.js";
import { Request } from "../requests/request.model.js";
import { Vehicle } from "./vehicle.model.js";
import { evaluateVehicleControl } from "./control.engine.js";
import { getIO } from "../../sockets/socket.js";

export const updateVehicleState = async (req, res) => {
  const sensor = await Sensor.findOne();
  if (!sensor) {
    return res.status(400).json({ message: "No sensor data available" });
  }

  // Latest request only
  const request = await Request.findOne().sort({ createdAt: -1 });
  const approvalStatus = request ? request.status : "PENDING";

  const decision = evaluateVehicleControl({
    sensorStatus: sensor.status,
    approvalStatus,
  });

  await Vehicle.findOneAndUpdate({}, decision, {
    upsert: true,
    new: true,
  });

  const io = getIO();
  io.emit("vehicle:update", decision);

  res.json(decision);
};
