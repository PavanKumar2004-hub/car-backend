import { SPEED_POLICY } from "./speed.policy.js";

export const evaluateVehicleControl = ({ sensorStatus, approvalStatus }) => {
  // Accident overrides everything
  if (sensorStatus.accident === "ACCIDENT") {
    return {
      lockState: "LOCKED",
      speedAllowed: SPEED_POLICY.STOPPED,
      reason: "Accident detected",
    };
  }

  // Alcohol safe → normal driving
  if (sensorStatus.alcohol === "SAFE") {
    return {
      lockState: "UNLOCKED",
      speedAllowed: SPEED_POLICY.NORMAL,
      reason: "Alcohol safe",
    };
  }

  // Alcohol danger but approved
  if (sensorStatus.alcohol === "DANGER" && approvalStatus === "APPROVED") {
    return {
      lockState: "LIMITED",
      speedAllowed: SPEED_POLICY.LIMITED,
      reason: "Approved by family member",
    };
  }

  // Alcohol danger & no approval
  return {
    lockState: "LOCKED",
    speedAllowed: SPEED_POLICY.STOPPED,
    reason: "Alcohol detected – no approval",
  };
};
