import express from "express";
import { protect } from "../../middlewares/auth.middleware.js";
import { login, register } from "./auth.controller.js";
import { resolveContextRole } from "../../middlewares/contextRole.middleware.js";

const router = express.Router();

router.post("/register", register);
router.post("/login", login);

router.get("/me", protect, (req, res) => {
  res.json({
    _id: req.user._id,
    name: req.user.name,
    email: req.user.email,
    role: req.user.role,
  });
});

router.get("/context", protect, resolveContextRole, (req, res) => {
  res.json({
    contextRole: req.contextRole, // OWNER | FAMILY | FRIEND
    dashboardOwnerId: req.dashboardOwnerId || req.user._id,
  });
});

export default router;
