import { User } from "../auth/user.model.js";
import { Member } from "./member.model.js";

/**
 * ADD MEMBER
 */
export const addMember = async (req, res) => {
  const { phone, relation, role } = req.body;

  const user = await User.findOne({ phone });

  if (!user) {
    return res.status(400).json({
      message: "User must register first before being added as a member",
    });
  }

  if (user._id.equals(req.user._id)) {
    return res.status(400).json({
      message: "You cannot add yourself as a member",
    });
  }

  const exists = await Member.findOne({
    ownerId: req.user._id,
    userId: user._id,
  });

  if (exists) {
    return res.status(400).json({
      message: "Member already added",
    });
  }

  const member = await Member.create({
    ownerId: req.user._id,
    userId: user._id,
    relation,
    role, // FAMILY | FRIEND
  });

  // 🔥 POPULATE BEFORE RETURNING
  const populatedMember = await Member.findById(member._id).populate(
    "userId",
    "name phone email"
  );

  res.status(201).json(populatedMember);
};

/**
 * GET MEMBERS
 */
export const getMembers = async (req, res) => {
  const ownerId =
    req.contextRole === "OWNER" ? req.user._id : req.dashboardOwnerId;

  const members = await Member.find({
    ownerId,
    status: "ACTIVE",
  })
    .populate("userId", "name phone email")
    .sort({ createdAt: -1 });

  res.json(members);
};

/**
 * UPDATE MEMBER
 */
export const updateMember = async (req, res) => {
  const { id } = req.params;
  const { relation, role, status } = req.body;

  const ownerId =
    req.contextRole === "OWNER" ? req.user._id : req.dashboardOwnerId;

  const member = await Member.findOne({
    _id: id,
    ownerId,
  });

  if (!member) {
    return res.status(404).json({
      message: "Member not found or access denied",
    });
  }

  // FRIEND cannot update
  if (req.contextRole === "FRIEND") {
    return res.status(403).json({
      message: "Access denied",
    });
  }

  // OWNER updating FAMILY should later require approval
  if (req.contextRole === "OWNER" && member.role === "FAMILY") {
    return res.status(403).json({
      message: "Approval required to update family member",
    });
  }

  member.relation = relation ?? member.relation;
  member.role = role ?? member.role;
  member.status = status ?? member.status;

  await member.save();

  res.json(member);
};

/**
 * DELETE MEMBER
 */
export const deleteMember = async (req, res) => {
  const { id } = req.params;

  const member = await Member.findById(id);

  if (!member) {
    return res.status(404).json({ message: "Member not found" });
  }

  // OWNER trying to delete FAMILY → needs approval
  if (req.contextRole === "OWNER" && member.role === "FAMILY") {
    return res.status(403).json({
      message: "Approval required to delete family member",
    });
  }

  // FRIEND cannot delete
  if (req.contextRole === "FRIEND") {
    return res.status(403).json({
      message: "Access denied",
    });
  }

  // FAMILY or OWNER (non-family member)
  await Member.deleteOne({ _id: id });

  res.json({ message: "Member removed successfully" });
};
